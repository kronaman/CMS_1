<?php require_once("../includes/config.php"); ?>

<!-- header -->
<?php include("../includes/layout/header.php"); ?>

<!-- Main content -->
<div class="container">
  <div id="page">
    <h2>Admin Menu</h2>
    <p>Welcome to the Admin area.</p>
    <ul>
      <li><a href="manage_content.php">Manage Website Content</a></li>
      <li><a href="manage_admins.php">Manage Admin Users</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </div>
</div>
    <!-- page ends here -->

<!-- Footer -->
<?php include("../includes/layout/footer.php"); ?>
