<?php require_once("../includes/config.php"); ?>

<!-- header -->
<?php include("../includes/layout/header.php"); ?>

<?php

$selected_subject = isset($_GET["subject"]) ?  $_GET["subject"] : null;
$selected_page = isset($_GET["page"]) ?  $_GET["page"] : null;

?>
<!-- Main content -->
<div id="wrapper">
<!-- Sidebar -->

  <div id="sidebar-wrapper">
    <ul class="sidebar-nav list-group">
     <?php
		$subject_set = find_all_subjects();

		 while ($subject = mysqli_fetch_assoc($subject_set)) {
		  	$page_set = find_pages_for_subject($subject["id"]);
		?>
	    <li class="list-group-item"><a href="manage_content.php?subject=<?php echo urlencode($subject["id"]); ?>" class="text-muted">
        	<?php  echo $subject["menu_name"]?></a>
        	<ul class="pages" style="list-style-type:square">
          		<?php  while($page = mysqli_fetch_assoc($page_set)) { ?>
            		<li>
            			<a href="manage_content.php?page=<?php echo urlencode($page["id"]); ?>"><?php echo $page["menu_name"]; ?></a>
            		</li>
          		<?php 
          			}
          			mysqli_free_result($page_set);
          		?>
	        </ul>
      	</li>
  		<?php
  			}
  			mysqli_free_result($subject_set); 
  		?>

		<?php 
		if(!empty($selected_subject))
			echo "Subject: ".$selected_subject; 
	  	elseif(!empty($selected_page))
			echo "Page: ".$selected_page; 
		?>
    </ul>
  </div>
  <!-- Page Content -->
  <div id="page-content-wrapper">
  	<div class="container-fluid">
		<div class="col-md-12">
			<a id="toggler" class="btn btn-info pull-left" href="#"><span class="h5">WC</span></a>
		<header>
			<a class="logo" href="#"><span class="navbar-h1">Widget Corp</span></a>
		</header><!-- /header -->
		<p class="text-success h3"><span class="highlight">Manage Content</span></p>  		
		</div>
  	</div>
  </div>
</div>
    <!-- page ends here -->

<!-- Footer -->
<?php include("../includes/layout/footer.php"); ?>
