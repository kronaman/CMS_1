<?php require_once("../includes/config.php"); ?>

<!-- header -->
<?php include("../includes/layout/header.php"); ?>

<?php

$selected_subject = isset($_GET["subject"]) ?  $_GET["subject"] : null;
$selected_page = isset($_GET["page"]) ?  $_GET["page"] : null;

?>
<!-- Main content -->
<div class="container-fluid">
  <div id="page">
  	<div class="col-sm-2 col-xs-6"></div>
  	<div class="col-sm-10 col-xs-6">
    	<p class="text-success h2"><span class="highlight">Manage Content</span></p>
  	</div>
    <div class="row">
    	<div class="col-sm-2 col-xs-5 sidenav">
		    <ul class="subjects list-group">
		     <?php
				$subject_set = find_all_subjects();

				 while ($subject = mysqli_fetch_assoc($subject_set)) {
				  	$page_set = find_pages_for_subject($subject["id"]);
				?>
			    <?php echo "<li ";
			    		if($selected_subject == $subject['id'] )
							echo "class=\"list-group-item selected\">";
						else
							echo "class=\"list-group-item \">" ;
						?>
			    	<a href="manage_content.php?subject=<?php echo urlencode($subject["id"]); ?>" class="text-muted">
		        	<?php  echo $subject["menu_name"]?></a>
		        	<ul class="pages" style="list-style-type:square">
		          		<?php  while($page = mysqli_fetch_assoc($page_set)) { ?>
		            		<?php echo "<li ";
			    		if($selected_page == $page['id'] )
							echo "class=\"selected\">";
						else
							echo ">" ;
						?>
	            		<a href="manage_content.php?page=<?php echo urlencode($page["id"]); ?>"><?php echo $page["menu_name"]; ?></a>
	            		</li>
		          		<?php 
		          			}
		          			mysqli_free_result($page_set);
		          		?>
			        </ul>
		      	</li>
		  		<?php
		  			}
		  			mysqli_free_result($subject_set); 
		  		?>
		    </ul>
  		</div>
  		<div class="col-sm109 col-xs-7">
  			<?php if(!empty($selected_subject))
  					echo "Subject: ".$selected_subject; 
  				  elseif(!empty($selected_page))
  					echo "Page: ".$selected_page; ?>
  		</div>
  	</div>
  </div>
</div>
    <!-- page ends here -->

<!-- Footer -->
<?php include("../includes/layout/footer.php"); ?>
