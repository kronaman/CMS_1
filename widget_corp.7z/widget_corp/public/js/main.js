$(function(){

$('#toggler').click(function(event) {
	event.preventDefault();
	$('#wrapper').toggleClass("show-sidebar");
	$('#sidebar-wrapper').addClass('animated').toggleClass("bounceInLeft");
});


	// if ($('#sidebar-wrapper').hasClass('bounceOutLeft')) {
	// 	$('#sidebar-wrapper').addClass('animated bounceInLeft').removeClass("animated bounceOutLeft");
	// } 
	// else if ($('#sidebar-wrapper').hasClass('bounceInLeft'))  {
	// 	$('#sidebar-wrapper').addClass('animated bounceOutLeft').removeClass("animated bounceInLeft");
	// }



});