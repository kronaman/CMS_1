<?php require_once("../includes/config.php"); ?>

<!-- header -->
<?php include("../includes/layout/header.php"); ?>

<!-- Main content -->
<div class="container">
  <div id="page">
    <h2 cal>Admin Menu</h2>
    <p class="text-success h1"><a href="admin.php"><span class="highlight">Admin</span></a></p>
    <ul class="list-group">
      <li class="list-group-item"><a href="manage_content.php">Manage Website Content</a></li>
      <li class="list-group-item"><a href="manage_admins.php">Manage Admin Users</a></li>
      <li class="list-group-item"><a href="logout.php">Logout</a></li>
    </ul>
  </div>
    <!-- page ends here -->
  <br><br><br>
<!-- Footer -->
<?php include("../includes/layout/footer.php"); ?>
</div>
