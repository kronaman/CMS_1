<!DOCTYPE html>
	<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
		<title>Widget Corp</title>
		<!-- <link href="stylesheets/public.css" media="all" rel="stylesheet" type="text/css" /> -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC|Raleway|Open+Sans+Condensed:300" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
	</head>
	<body>
	
		
<!-- Navigation -->
<?php include("../includes/layout/navigation.php"); ?>