    <!-- Footer -->
    <!-- <div id="footer"></div> -->
    <!-- footer ends here -->
   <footer>
   	<p>Copyright 2020, Widget Corp</p>
   </footer>

	</body>
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/bootstrap.min.js" type="text/javascript"></script>
  <script src="js/main.js" type="text/javascript"></script>
</html>
<?php
  // 5. Close database connection
  if($connection){
  	mysqli_close($connection);
  }
?>
